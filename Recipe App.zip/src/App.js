import React from 'react';
import './components/styles.css';
import Meal from './components/Meal';
function App() {
  return(
      <Meal/>
  )
  
}

export default App;

